you can run file using following command :

pdflatex '57.tex'

bibtex 'reference'

pdflatex '57.tex'
