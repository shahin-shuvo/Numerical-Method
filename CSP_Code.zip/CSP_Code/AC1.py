import queue


class CSP_AC1:
    qu = queue.Queue()

    def __init__(self, arcs, domains, constraints):
        self.arcs = arcs
        self.domains = domains
        self.constraints = constraints


    def revise(self, xi, xj):
        revised = False
        domain_i = self.domains[xi]
        constraints = []
        for constraint in self.constraints:
            if (constraint[0] == xi and constraint[1] == xj):
                constraints.append(constraint)

        for x in domain_i[:]:
            isSatisfied = False
            for y in self.domains[xj]:
                for constraint in constraints:
                    isValid = self.constraints[constraint]
                    if isValid(x, y):
                        isSatisfied = True

            if not isSatisfied:
                domain_i.remove(x)
                revised = True

        return revised

    def AC1(self):
        isChanged1 = True
        isChanged2 = True
        while True:
            for arc in self.arcs:
                isChanged1 = self.revise(arc[0],arc[1])
                isChanged2 = self.revise(arc[1], arc[0])

            if(isChanged1==False and isChanged2==False):
                break


        return self.domains