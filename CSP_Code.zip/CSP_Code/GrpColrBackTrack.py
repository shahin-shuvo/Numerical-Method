class BackTrack():


    def __init__(self,arcs,domains,constraints):
        self.arcs = arcs
        self.domains = domains
        self.constraints = constraints
        self.nodes = {}
        i = 0
        for node in self.domains:
            self.nodes[i] = node
            i = i + 1


    def isSafe(self,node,color,colorResult):
        safe = False
        node_arc=[]
        for arc in self.arcs:
            if(arc[0]==node or arc[1]==node):
                node_arc.append(arc)

        for arc in node_arc:
            for constraint in self.constraints:
                if (constraint[0] == arc[0] or constraint[1] == arc[0] or
                        constraint[1] == arc[1] or constraint[0] == arc[1]):

                    isValid = self.constraints[constraint]
                    if isValid(arc[0], arc[1]):
                        safe = True
                        return safe

        return safe

    def backTrackUtil(self,count,colorResult,node):

        if count==len(self.domains):
            return colorResult

        for color in self.domains[node]:
            if self.isSafe(node[0],color,colorResult):
                colorResult[node[0]] = color

                if(self.backTrackUtil(count+1,colorResult,self.nodes[count]))==True:
                    return True
                colorResult[node[0]] = 0


    def backTrackHelper(self):
        colorResult={}
        result = self.backTrackUtil(0,colorResult,self.nodes[0])
        print(colorResult)