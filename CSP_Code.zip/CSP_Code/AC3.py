import queue


class CSP_AC3:
    qu = queue.Queue()

    def __init__(self, arcs, domains, constraints):
        self.arcs = arcs
        self.domains = domains
        self.constraints = constraints


    def revise(self, xi, xj):
        revised = False
        domain_i = self.domains[xi]

        constraints = []
        for constraint in self.constraints:
            if (constraint[0] == xi and constraint[1] == xj):
                constraints.append(constraint)

        for x in domain_i[:]:
            isSatisfied = False
            for y in self.domains[xj]:
                for constraint in constraints:
                    isValid = self.constraints[constraint]
                    if isValid(x, y):
                        isSatisfied = True

            if not isSatisfied:
                domain_i.remove(x)
                revised = True

        return revised



    def AC3(self):
        #push all arc and its revers
        for arc in self.arcs:
            self.qu.put(arc)

        while not self.qu.empty():
            x,y = self.qu.get()
            isChanged = self.revise(x, y)
            if isChanged:
                if len(self.domains[x]) == 0:
                    return None
                    break
                #if changed then push all of its neighbours
                neighbors = []
                for neighbor in self.arcs:
                    if neighbor[0] == y:
                        neighbors.append(neighbor)

                for neighbor in neighbors:
                    self.qu.put(neighbor)


        return self.domains



