from AC3 import CSP_AC3
from AC1 import CSP_AC1
from GrpColrBackTrack import BackTrack
import time
def graph_create():
        #initialize color
        Red = 1
        Blue = 2
        Green = 3
        Violet = 4
        Yellow = 5
        arcs = [('a', 'b'), ('b', 'a'),
                ('a', 'c'), ('c', 'a'),
                ('c', 'd'), ('d', 'c'),
                ('d', 'e'), ('e', 'd'),
                ('a', 'e'), ('e', 'a'),]

        domains = {
            'a': [Red,Green],
            'b': [Red,Green,Blue],
            'c': [Red,Blue,Violet],
            'd': [Red,Green,Blue],
            'e': [Red,Green,Blue,Yellow]}

        # constraints:a != b

        constraints = {
            ('a', 'b'): lambda a, b: a != b,
            ('b', 'a'): lambda b, a: b != a,
            ('b', 'a'): lambda b, a: b != Red,
            ('a', 'c'): lambda a, c: a != c,
            ('c', 'a'): lambda c, a: c != a,
            ('c', 'a'): lambda c, a: c != Blue,
            ('c', 'd'): lambda c, d: c != d,
            ('d', 'c'): lambda d, c: d != c,
            ('d', 'e'): lambda d, e: d != e,
            ('e', 'd'): lambda e, d: e != d,
            ('e', 'd'): lambda e, d: e != Red,
            ('a', 'e'): lambda a, e: a != e,
            ('e', 'a'): lambda e, a: e != a,
            ('e', 'a'): lambda e, a: e == Yellow,
            ('a', 'd'): lambda a, d: a == d
        }

        #AC3
        reduced_domain = CSP_AC3(arcs, domains, constraints)
        print ("AC3 :" ,reduced_domain.AC3())

        #AC1
        reduced_domain = CSP_AC1(arcs, domains, constraints)
        print ("AC1 :" ,reduced_domain.AC1())

        #CSP
        mapcolor = BackTrack(arcs, domains, constraints)
        mapcolor.backTrackHelper()







if __name__ == "__main__":
     graph_create()
