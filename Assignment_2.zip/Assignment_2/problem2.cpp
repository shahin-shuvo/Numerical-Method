#include<bits/stdc++.h>
using namespace std;

double func(double x)
{
    return exp(-.5*x)*(4-x)-2;
}

double derivFunc(double x)
{
    return .5*exp(-.5*x)*x-3*exp(-.5*x);
}

void newtonRaphson(double point,double tolerance)
{
    char filename[35] = "newtonRaphson.csv";
    FILE *fp;
    fp = fopen(filename,"w+");
    fprintf(fp,"Iteration, Relative Aproximate Error\n");



    double error=0.0,prevPoint=0.0;
    double presentPoint = point;
    double thrs = tolerance;
    cout<<"Ite\tXi\t f(Xi)\t     f'(Xi)\t  Error  \n";
    std::cout << std::setprecision(5) << std::fixed;
    for(int i=0;; i++)
    {

        if(i>0)
        {
            error = abs((presentPoint-prevPoint)/presentPoint);

            cout<<i<<"\t"<<presentPoint<<"\t"<<func(presentPoint)<<"\t"<<derivFunc(presentPoint)<<"\t"<<error*100<<"%"<<endl;
            fprintf(fp,"%d, %.20lf\n",i,error);
            if(error<=thrs) break;

        }
        else
        {
            cout<<i<<"\t"<<presentPoint<<"\t"<<func(presentPoint)<<"\t"<<derivFunc(presentPoint)<<"\t"<<"--"<<"%"<<endl;
        }

        prevPoint=presentPoint;
        presentPoint = prevPoint - func(prevPoint)/derivFunc(prevPoint);


    }
    cout << "The value of root is : " << presentPoint;
}

int main()
{
    double tolerance;
    cout<<"Give your acceptable tolerance: ";
    cin>>tolerance;
    newtonRaphson(8,tolerance);

    return 0;
}


