#include<bits/stdc++.h>
using namespace std;

double errorThrs;

double func(double m)
{
    double v=35, g=9.8,c=15,t=9;
    return (v - ( ((g*m)/c) * (1 - exp((-1*c/m)*t)) ));
}

double errorCalculate(double xl, double xu)
{
    return (fabs((xu - xl) / (xu + xl)) * 100.0);
}

void bisection(double xl, double xu)
{

    if(func(xl) * func(xu) >= 0)
    {
        printf("Wrong guess of xl and/or xu\n");
        return;
    }

    printf("\titer\tupper\t\tlower\t\txr\t\tf(xr)\tError\n");

    double xr = 0.0;
    int iteration = 0;

    while(errorCalculate(xl, xu) > errorThrs)
    {

        xr = (xl + xu) / 2;

        if(func(xr) == 0.0)
        {
            break;
        }
        else
        {
            printf("%6d\t%.6lf\t%0.6lf\t%0.6lf\t%0.6lf\t%0.6lf\n", ++iteration, xl, xu, xr, func(xr), errorCalculate(xl, xu));

        }

        if(func(xl) * func(xr) < 0.0)
        {
            xu = xr;
        }
        else
        {
            xl = xr;
        }
    }

    printf("Root is = %0.5lf\n", xr);
}

int main()
{
    //freopen("prob1A.csv", "w", stdout);
    double xl,xu;
    printf("Enter lower and upper bound:\n");
    scanf("%lf %lf", &xl, &xu);
    printf("Enter accepted errror tolerance:\n");
    scanf("%lf", &errorThrs);
     //freopen("prob1A.csv", "w", stdout);
    for(double i =xl; i<=xu; i+=0.1)
    {
        printf("%0.6lf\t%0.6lf\n",i,func(i));
    }
    bisection(xl, xu);

    return 0;
}
