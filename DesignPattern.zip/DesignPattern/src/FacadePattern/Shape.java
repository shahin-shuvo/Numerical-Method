package FacadePattern;

public interface Shape {
    void draw();
}
