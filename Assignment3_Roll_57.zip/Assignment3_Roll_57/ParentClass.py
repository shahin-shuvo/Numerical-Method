import re
import numpy as np
import pandas as pd


# we know Ax = b
# A is the coefficient matrix
# x is the variables
# b is the value of right handside

class ParentClass:
    # This function will parse the equation and extract the value
    def Equation_Parsing(file: str, regex=r'([+-]?\d*)([A-Z]|[a-z]\d*)'):
        regex = re.compile(regex)
        input = open(file, "r")

        coefficients = []
        b = []
        for line in input:
            line = line.strip().replace(' ', '')
            left, right = line.split('=')

            c_dict = {}
            for sign, v in regex.findall(left):
                if (sign == '' or sign == '+'):
                    co_effi = 1.0
                elif sign == '-':
                    co_effi = -1.0
                else:
                    co_effi = float(sign)

                c_dict[v] = co_effi
            b.append(right)
            coefficients.append(c_dict)
        input.close()
        return coefficients, b

    # This function will build the matrix for further calculation or row operation

    def build_Matrix(coefficients, b):
        b = np.array(b, dtype='float').reshape(len(b), 1)
        A = pd.DataFrame(coefficients)
        A.fillna(0, inplace=True)
        x = list(A.columns.values)
        A = A.values
        return x, A, b