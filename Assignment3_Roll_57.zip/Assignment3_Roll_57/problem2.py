from ParentClass import *


def inverse_Matrix(A):
    det_A = np.linalg.det(A)
    if(det_A == 0) :
        raise ValueError("Not invertible")
    if (A.shape[0] != A.shape[1]):
        raise ValueError("Not square!")
    rows = A.shape[0]

    A = np.concatenate((A, np.identity(rows, dtype='float')), axis=1)

    for i in range(rows - 1):
        for row in range(i + 1, rows):
            function_i_j = A[row, i] / A[i, i]
            A[row, i:] = A[row, i:] - function_i_j * A[i, i:]

    for i in reversed(range(rows)):
        A[i, :] = A[i, :] / A[i, i]
        for row in reversed(range(0, i)):
            function_i_j = A[row, i] / A[i, i]
            A[row, i:] = A[row, i:] - function_i_j * A[i, i:]

    return A[:, rows:]


if __name__ == '__main__':
    p, q = ParentClass.Equation_Parsing("input.txt")
    x, A, b = ParentClass.build_Matrix(p, q)

    value = np.dot(inverse_Matrix(A), b)

    f = open('output2.txt', 'w')
    for i in range(len(b)):
        print(str(x[i]) + "=" + str(value[i,0]) + '\n')
        f.write(str(x[i]) + "=" + str(value[i,0]) + '\n')

