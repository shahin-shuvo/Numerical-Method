from ParentClass import *

# we know Ax = b
# A is the coefficient matrix
# x is the variables
# b is the value of right handside

def cramersMethod(A: np.array, b):
    b = np.ravel(b)
    if (A.shape[1] != b.shape[0] and A.shape[0] != A.shape[1]):
        print('Error!')

    values = np.zeros((1, len(b)))
    det_A = np.linalg.det(A)

    for i in range(len(b)):
        temp = np.copy(A)
        temp[:, i] = b
        det_temp = np.linalg.det(temp)
        values[0][i] = det_temp / det_A

    return values


if __name__ == '__main__':
    p, q = ParentClass.Equation_Parsing("input.txt")
    x, A, b = ParentClass.build_Matrix(p, q)

    value = cramersMethod(A, b)
    f = open('output1.txt', 'w')
    for i in range(len(b)):
        print(str(x[i]) + "=" + str(value[0][i]) + '\n')
        f.write(str(x[i]) + "=" + str(value[0][i]) + '\n')

